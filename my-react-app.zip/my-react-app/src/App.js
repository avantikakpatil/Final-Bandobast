import React from 'react';
import './App.css';
import Navbar from './Components/Navbar';
import Dashboard from './Components/Dashboard';
import Header from './Components/Header';

function App() {
  return (
    <div className="App">
      <Dashboard />
    </div>
  );
}

export default App;
