import React from 'react';

class Sidebar extends React.Component {
  render() {
    return (
      <div className="sidebar">
        <div className="sidebar-header">
          <h2>Sidebar</h2>
        </div>
       
        <div className="navbar-footer">
         
        </div>
      </div>
    );
  }
}

export default Sidebar;
