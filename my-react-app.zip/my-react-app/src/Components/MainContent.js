import React from 'react';

class MainContent extends React.Component {
  render() {
    return (
      <div className="main-content">
        <h2>Main Content</h2>
        {/* Add your main content here */}
      </div>
    );
  }
}

export default MainContent;
